// src/App.jsx
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import DashboardPage from './pages/DashboardPage';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import ChatLayout from './pages/ChatLayout';
import ChatPage from './pages/ChatPage';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />

        {/* Chat routes: ChatLayout as parent, ChatPage as child */}
        <Route path="/chat" element={<ChatLayout />}>
          <Route path=":otherUserId" element={<ChatPage />} />
        </Route>

        {/* Catch-all: redirect to login */}
        <Route path="*" element={<LoginPage />} />
      </Routes>
    </Router>
  );
}
