// src/components/Sidebar.jsx
import { Link } from 'react-router-dom';

export default function Sidebar({ friends, friendRequests, onAccept, onReject }) {
  return (
    <div className="p-3 border-end" style={{ width: '250px', height: '100vh' }}>
      <h5>Friend Requests</h5>
      {friendRequests.length === 0 && <div>No pending requests</div>}
      {friendRequests.map((req) => (
        <div key={req._id} className="mb-2">
          {req.name}
          <button className="btn btn-sm btn-success ms-2" onClick={() => onAccept(req._id)}>Accept</button>
          <button className="btn btn-sm btn-danger ms-1" onClick={() => onReject(req._id)}>Reject</button>
        </div>
      ))}

      <h5 className="mt-4">Friends</h5>
      {friends.map((friend) => (
        <div key={friend._id} className="d-flex justify-content-between align-items-center mb-2">
          {friend.name}
          <Link to={`/chat/${friend._id}`} className="btn btn-primary btn-sm">Chat</Link>
        </div>
      ))}
    </div>
  );
}
