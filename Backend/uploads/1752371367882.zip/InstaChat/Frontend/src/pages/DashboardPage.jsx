import { useEffect, useState } from 'react';
import { getMe, acceptFriendRequest } from '../api/user';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

export default function DashboardPage() {
  const [user, setUser] = useState(null);
  const [msg, setMsg] = useState('');
  const [allUsers, setAllUsers] = useState([]);
  const navigate = useNavigate();

  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!token) {
      navigate('/login');
    } else {
      loadData();
      loadAllUsers();
    }
  }, []);

  const loadData = async () => {
    try {
      const res = await getMe(token);
      setUser(res.data);
      localStorage.setItem('userId', res.data._id); // Save userId for chat
    } catch (err) {
      setMsg('Failed to load data');
    }
  };

  const loadAllUsers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/user/all', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAllUsers(res.data);
    } catch (err) {
      // ignore
    }
  };

  const handleAccept = async (requesterId) => {
    try {
      await acceptFriendRequest(token, requesterId);
      setMsg('Friend request accepted!');
      loadData();
      loadAllUsers();
    } catch (err) {
      setMsg('Failed to accept request');
    }
  };

  const handleReject = async (requesterId) => {
    try {
      await axios.post('http://localhost:5000/api/friends/reject', { requesterId }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMsg('Friend request rejected!');
      loadData();
      loadAllUsers();
    } catch (err) {
      setMsg('Failed to reject request');
    }
  };

  const handleSendRequest = async (targetUserId) => {
    try {
      await axios.post('http://localhost:5000/api/friends/send', { targetUserId }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMsg('Friend request sent!');
      loadAllUsers();
    } catch (err) {
      setMsg('Failed to send request');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  if (!user) return <div className="text-center mt-5">Loading...</div>;

  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Welcome, {user.name} 👋</h2>
        <button className="btn btn-danger" onClick={handleLogout}>Logout</button>
      </div>

      {msg && <div className="alert alert-info">{msg}</div>}

      <div className="row">
        <div className="col-md-4 mb-4">
          <h4>All Users</h4>
          <ul className="list-group">
            {allUsers.length === 0 && <li className="list-group-item">No users to add</li>}
            {allUsers.map(u => (
              <li key={u._id} className="list-group-item d-flex justify-content-between align-items-center">
                <span>{u.name} ({u.email})</span>
                <button className="btn btn-primary btn-sm" onClick={() => handleSendRequest(u._id)}>
                  Send Request
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-md-4 mb-4">
          <h4>Friends</h4>
          <ul className="list-group">
            {user.friends.length === 0 && <li className="list-group-item">No friends yet</li>}
            {user.friends.map(friend => (
              <li key={friend._id} className="list-group-item d-flex justify-content-between align-items-center">
                <span>{friend.name} ({friend.email})</span>
                <Link to={`/chat/${friend._id}`} className="btn btn-success btn-sm">Chat</Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-md-4 mb-4">
          <h4>Pending Friend Requests</h4>
          <ul className="list-group">
            {user.friendRequests.length === 0 && <li className="list-group-item">No pending requests</li>}
            {user.friendRequests.map(request => (
              <li key={request._id} className="list-group-item d-flex justify-content-between align-items-center">
                <div>{request.name} ({request.email})</div>
                <div>
                  <button className="btn btn-success btn-sm me-2" onClick={() => handleAccept(request._id)}>Accept</button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleReject(request._id)}>Reject</button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}