// backend/index.js
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const path = require('path');
require('dotenv').config();

const connectDB = require('./config'); // ✅ connect db

const authRoutes = require('./routes/authRoutes');
const friendRoutes = require('./routes/friendRoutes');
const messageRoutes = require('./routes/messageRoutes');
const userRoutes = require('./routes/userRoutes');

const app = express();
const server = http.createServer(app);

// Connect to DB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/friends', friendRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/user', userRoutes);

// Socket.io
const io = new Server(server, { cors: { origin: '*' } });
const onlineUsers = {};

io.on('connection', (socket) => {
  console.log('✅ New client connected:', socket.id);

  socket.on('join', (userId) => {
    onlineUsers[userId] = socket.id;
    console.log('✅ User joined:', userId);
  });

  socket.on('sendMessage', (msg) => {
    const targetSocketId = onlineUsers[msg.to];
    if (targetSocketId) {
      io.to(targetSocketId).emit('receiveMessage', msg);
    }
  });

  socket.on('disconnect', () => {
    console.log('❌ Client disconnected:', socket.id);
    for (let userId in onlineUsers) {
      if (onlineUsers[userId] === socket.id) {
        delete onlineUsers[userId];
        break;
      }
    }
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
